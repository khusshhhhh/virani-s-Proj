const BASE_URL = "https://virani-s-proj.onrender.com";
